#include "Passenger.hpp"

using namespace std;

Passenger::Passenger(string username) : User(username){
}