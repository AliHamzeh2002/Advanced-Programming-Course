#include "Driver.hpp"

using namespace std;

Driver::Driver(string username) : User(username){
}