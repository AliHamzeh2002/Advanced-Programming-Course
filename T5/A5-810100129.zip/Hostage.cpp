#include "Hostage.hpp"

Hostage::Hostage(Point init_pos) : GameObject(init_pos, HOSTAGE_VX, HOSTAGE_VY, HOSTAGE_HEIGHT, HOSTAGE_WIDTH, HOSTAGE_IMG){
    
}