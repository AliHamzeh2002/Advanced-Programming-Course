#include "src/rsdl.hpp"

struct ObjectOnMapData{
    char object_type;
    int row;
    int col;
};