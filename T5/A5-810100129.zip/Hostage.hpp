#ifndef HOSTAGE_H

#define HOSTAGE_H

#include "GameObject.hpp"

class Hostage : public GameObject{
    public:
        Hostage(Point init_pos);
};

#endif